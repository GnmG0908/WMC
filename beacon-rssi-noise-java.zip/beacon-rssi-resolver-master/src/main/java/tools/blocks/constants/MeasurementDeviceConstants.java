package tools.blocks.constants;

/**
 * Created by fgroch on 29.08.16.
 */
public interface MeasurementDeviceConstants {
    double getCoefficientA();
    double getCoefficientB();
    double getCoefficientC();
}
